def madd(a,b,di):
    if di=='2*2':
        r=[[0,0],[0,0]]
    elif di=='2*3':
        r=[[0,0,0],[0,0,0]]
    elif di=='3*2':
        r=[[0,0],[0,0],[0,0]]
    elif di=='3*3':
        r=[[0,0,0],[0,0,0],[0,0,0]]
    elif di=='3*1':
        r=[[0],[0],[0]]
    elif di=='1*3':
        r=[[0,0,0]]
    elif di=='4*4':
        r=[[0,0,0,0],[0,0,0,0],[0,0,0,0]]
    else:
        print('INVALID INPUT!!!')
    for i in range(len(r)):
        for j in range(len(r[0])):
            r[i][j]=a[i][j]+b[i][j]

def mmultiply(a,b,di):
    if di=='2*2':
        r=[[0,0],[0,0]]
    elif di=='2*3':
        r=[[0,0,0],[0,0,0]]
    elif di=='3*2':
        r=[[0,0],[0,0],[0,0]]
    elif di=='3*3':
        r=[[0,0,0],[0,0,0,],[0,0,0]]
    elif di=='1*3':
        r=[[0,0,0]]
    elif di=='3*1':
        r=[[0],[0],[0]]
    elif di=='4*4':
        r=[[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0]]
    else:
        print('invalid input!!!')
    for i in range(len(r)):
        for j in range(len(r[0])):
            for k in range(len(b)):
                r[i][j]+=a[i][k]*b[k][j]
    return r

def msub(a,b,di):
    if di=='2*2':
        r=[[0,0],[0,0]]
    elif di=='2*3':
        r=[[0,0,0],[0,0,0]]
    elif di=='3*2':
        r=[[0,0],[0,0],[0,0]]
    elif di=='3*3':
        r=[[0,0,0],[0,0,0],[0,0,0]]
    elif di=='1*3':
        r=[[0,0,0]]
    elif di=='3*1':
        r=[[0],[0],[0]]
    elif di=='4*4':
        r=[[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0,]]
    else:
        r=[]
    if r==[]:
        return 'INVALID INPUT!!!'
    else:
        for i in range(len(r)):
            for j in range(len(r[0])):
                r[i][j]=a[i][j]-b[i][j]
        return r

def transpose(a,di):
    if di=='2*2':
        r=[[0,0],[0,0]]
    elif di=='2*3':
        r=[[0,0],[0,0],[0,0]]
    elif di=='3*2':
        r=[[0,0,0],[0,0,0]]
    elif di=='3*3':
        r=[[0,0,0],[0,0,0],[0,0,0]]
    elif di=='1*3':
        r=[[0],[0],[0]]
    elif di=='3*1':
        r=[[0,0,0]]
    elif di=='4*4':
        r=[[0,0,0,0],[0,0,0,0],[0,0,0,0],[0,0,0,0,]]
    else:
        r=[]
    if r==[]:
        return 'INVALID INPUT'
    else:
        for i in range(len(a)):
            for j in range(len(a[0])):
                r[j][i]=a[i][j]
        return r

def inverse(a):
    print(list(map(list,zip(*a))))

