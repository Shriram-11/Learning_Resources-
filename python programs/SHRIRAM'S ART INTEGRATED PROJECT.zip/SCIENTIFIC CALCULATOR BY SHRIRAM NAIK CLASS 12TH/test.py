import math
a=math.asin(1)
print(math.degrees(a))
